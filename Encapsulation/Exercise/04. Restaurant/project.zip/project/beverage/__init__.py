class Beverage:
    pass


class HotBeverage:
    pass

