from project.elf import Elf
from project.hero import Hero
from project.dark_knight import DarkKnight


class BladeKnight(DarkKnight):
    pass

